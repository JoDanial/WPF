﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TelerikDataEntryOperatorsDemo
{
    /// <summary>
    /// Interaction logic for AutoCompleteTextBoxDemo.xaml
    /// </summary>
    public partial class AutoCompleteTextBoxDemo : Window
    {
        public AutoCompleteTextBoxDemo()
        {
            InitializeComponent();
            this.Loaded += AutoCompleteTextBoxDemo_Loaded;
        }

        void AutoCompleteTextBoxDemo_Loaded(object sender, RoutedEventArgs e)
        {
            
        }
    }

    public class Employee
    {
        public string FullName { get; set; }
    }

    public class ViewModel
    {
        public ObservableCollection<Employee> Employees { get; set; }

        public ViewModel()
        {
            this.Employees = new ObservableCollection<Employee> { 
            new Employee{ FullName = "John"},
            new Employee{ FullName = "Tom"},
            new Employee{ FullName = "Joe"},
            new Employee{ FullName = "Joseph"},
            new Employee{ FullName = "Josef"},
            new Employee{ FullName = "Jojo"},
            new Employee{ FullName = "Jackie"},
            new Employee{ FullName = "Jack"},
            new Employee{ FullName = "Justin"},
            new Employee{ FullName = "Phil"},
            new Employee{ FullName = "Dan"}
            };
        }
    }
}
