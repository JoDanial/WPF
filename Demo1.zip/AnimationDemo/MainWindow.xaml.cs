﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AnimationDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            this.Loaded += MainWindow_Loaded;
        }

        void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            DoubleAnimation ani = new DoubleAnimation();
            ani.From = 50;
            ani.To = 150;
            ani.Duration = TimeSpan.Parse("0:0:3");

            DoubleAnimation aniWidth = new DoubleAnimation();
            aniWidth.From = 50;
            aniWidth.To = 150;
            aniWidth.Duration = TimeSpan.Parse("0:0:3");

            
            DoubleAnimation aniFont = new DoubleAnimation();
            aniFont.From = 10;
            aniFont.To = 48;
            aniFont.Duration = TimeSpan.Parse("0:0:3");

            Storyboard sb = new Storyboard();
            sb.Children.Add(ani);
            sb.Children.Add(aniWidth);
            sb.Children.Add(aniFont);

            Storyboard.SetTargetName(ani, "btn");
            Storyboard.SetTargetProperty(ani, new PropertyPath(Button.HeightProperty));
            Storyboard.SetTargetName(aniWidth, "btn");
            Storyboard.SetTargetProperty(aniWidth, new PropertyPath(Button.WidthProperty));
            Storyboard.SetTargetName(aniFont, "btn");
            Storyboard.SetTargetProperty(aniFont, new PropertyPath(Button.FontSizeProperty));

            sb.Begin(btn);  

            //btn.BeginAnimation(WidthProperty, ani);
            //btn.BeginAnimation(HeightProperty, ani);

        }
    }
}
