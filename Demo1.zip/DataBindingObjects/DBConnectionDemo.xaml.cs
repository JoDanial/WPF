﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DataBindingObjects
{
    /// <summary>
    /// Interaction logic for DBConnectionDemo.xaml
    /// </summary>
    public partial class DBConnectionDemo : Window
    {
        public DBConnectionDemo()
        {
            InitializeComponent();
            this.Loaded += DBConnectionDemo_Loaded;
        }

        void DBConnectionDemo_Loaded(object sender, RoutedEventArgs e)
        {
            DataClasses1DataContext db = new DataClasses1DataContext();
            var actors = (from a in db.Actors
                          select a).ToList();
            lbx.ItemsSource = actors;
            lbx.DisplayMemberPath = "FirstName";
        }
    }
}
