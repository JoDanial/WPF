﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;

namespace DataBindingObjects
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            this.Loaded += MainWindow_Loaded;
        }
        
        Employee employee;

        ObservableCollection<Employee> employees;

        void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            employee = new Employee { FirstName="Peter", LastName="Parker" };
 
            employees = new ObservableCollection<Employee> { 
                new Employee { FirstName="Peter", LastName="Parker" },
                new Employee { FirstName="Jackie", LastName="Chan" },
                new Employee { FirstName="Jet", LastName="Li" },
                new Employee { FirstName="Bruce", LastName="Lee" }
            };

            sp.DataContext = employee;
           
            lbx.ItemsSource = employees;
            lbx.DisplayMemberPath = "FullName";
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(employee.FirstName + " " + employee.LastName);
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            employee.FirstName = "Carl";
            employee.LastName = "Kent";
        }
    }
}
