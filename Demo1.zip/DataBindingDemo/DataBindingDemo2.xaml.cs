﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DataBindingDemo
{
    /// <summary>
    /// Interaction logic for DataBindingDemo2.xaml
    /// </summary>
    public partial class DataBindingDemo2 : Window
    {
        public DataBindingDemo2()
        {
            InitializeComponent();
            this.Loaded += DataBindingDemo2_Loaded;
        }

        void DataBindingDemo2_Loaded(object sender, RoutedEventArgs e)
        {
            Employee emp = new Employee { FirstName = "Jet", LastName = "Li"};
            sp.DataContext = emp;

            //Binding bFName = new Binding("FirstName");
            ////bFName.Source = emp;
            //tbkFName.SetBinding(TextBlock.TextProperty, bFName);

            //Binding bLName = new Binding("LastName");
            ////bLName.Source = emp;
            //tbkLName.SetBinding(TextBlock.TextProperty, bLName);

        }
    }

    public class Employee
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
